#if !defined (VONESETTING_H)
#define VONESETTING_H
#else
#error Multiple includes of vonesetting.h
#endif

#define WIFI_SSID "Ubi"          //Replace this with YOUR WiFi SSID
#define WIFI_PASSWORD "Chin55668880+h"  //Replace this with YOUR WiFi Password

#define MQTT_SERVER "mqtt.v-one.my"
#define MQTT_PORT 8883
#define MQTT_USERNAME "EAfXDx7T0NZG3LOK"  //Replace this with the Access Token of YOUR gateway
#define MQTT_PASSWORD " "

#define GATEWAYID "849ab84d-e8c1-473b-829a-ce331bdce013"  //Replace this with the gatewayID of your gateway
#define INTERVAL 1000 //1S
#define INTERVAL2 500 //0.5S
